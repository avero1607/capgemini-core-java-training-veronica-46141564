package programs;

import java.util.Arrays;
import java.util.Scanner;

public class Permutation {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Total Number N = ");
		int N = sc.nextInt();
		int[] array = new int[N];
		for (int i = 0; i < N; i++) {
			int j = i + 1;
			System.out.println("Number #" + j + ": ");
			array[i] = sc.nextInt();
		}
		Permutation p = new Permutation();
		System.out.println("The permutations of " + Arrays.toString(array) + " are: ");
		p.findPermutation(array, array.length, array.length);
	}

	void printPermutations(int array[], int n) {
		for (int i = 0; i < n; i++)
			System.out.print(array[i] + " ");
		System.out.println();
	}

	void findPermutation(int array[], int size, int n) {
		if (size == 1)
			printPermutations(array, n);
		for (int i = 0; i < size; i++) {
			findPermutation(array, size - 1, n);
			if (size % 2 == 1) {
				int temp = array[0];
				array[0] = array[size - 1];
				array[size - 1] = temp;
			} else {
				int temp;
				temp = array[i];
				array[i] = array[size - 1];
				array[size - 1] = temp;
			}
		}
	}

}