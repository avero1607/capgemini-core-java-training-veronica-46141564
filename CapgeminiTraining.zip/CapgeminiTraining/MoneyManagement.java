package programs;

import java.util.Scanner;

public class MoneyManagement {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your income this month: ");
		int account0 = sc.nextInt();
		System.out.println(moneyManagement(account0));
	}

	private static String moneyManagement(int account0) {
		double account1 = 0.55 * account0;
		double account2 = 0.1 * account0;
		double account3 = 0.1 * account0;
		double account4 = 0.1 * account0;
		double account5 = 0.1 * account0;
		double account6 = 0.05 * account0;
		return "NEC: " + account1 + " LTSS: " + account4 + 
				"\nFFA: " + account2 + " PLAY: " + account5 +
				"\nEDU: " + account3 + " GIVE: " + account6 ;
	}

}
