package programs;

public class HumanResourceManagement {

	public class Employee {
		String name;
		String email;
		String address;
		String birthday;

		void work() {
			System.out.println("Working");
		}
	}

	public class Programmer extends Employee {
		String programmingLanguages;

		void code() {
			System.out.println("Coding");
		}

		void fixBugs() {
			System.out.println("Fixing Bugs");
		}
	}

	public class Tester extends Employee {
		String testingMethodologies;

		void test() {
			System.out.println("Testing");
		}

		void verify() {
			System.out.println("Verifying");
		}
	}

	public class Designer extends Employee {
		String designPhilosophy;
		String designToolsUsed;

		void design() {
			System.out.println("Designing");
		}
	}

	public class BusinessDeveloper extends Employee {
		String specializedDomains;

		void collectRequirements() {
			System.out.println("Collecting Requirements");
		}

		void analyzeRequirements() {
			System.out.println("Analyzing Requirements");
		}

		void writeDocuments() {
			System.out.println("Writing Documents");
		}
	}

	public class TeamLeader extends Programmer {
		String teamCollaborationTools;
		String developmentMethods;

		void schedule() {
			System.out.println("Scheduling");
		}

		void organize() {
			System.out.println("Organizing");
		}

		void manageProgrammers() {
			System.out.println("Managing Programmers");
		}

		void designers() {
			System.out.println("Designing");
		}

		void testers() {
			System.out.println("Tester");
		}
	}

	public class Architect extends Programmer {
		String designMethodology;

		void designSystem() {
			System.out.println("Designing System");
		}
	}

	public class CTO extends Architect {
		String technologyDomains;

		void adviseTechnologies() {
			System.out.println("Advising Technologies");
		}
	}

	public class CEO extends Employee {
		String vision;
		String mission;

		void executiveManagement() {
			System.out.println("Executive Management");
		}
	}

	public class CFO extends Employee {
		String financeManagementSkills;

		void manageFinance() {
			System.out.println("Managing Finance");
		}
	}

}
