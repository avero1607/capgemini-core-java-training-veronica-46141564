package programs;

import java.util.Scanner;

public class FactorialInNumberAndWords {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("N = ");
		int N = sc.nextInt();
		factorialInNumberAndWords(N);
	}

	private static void factorialInNumberAndWords(int n) {
		int fact = 1;
		for (int i = 1; i <= n; i++) {
			fact = fact * i;
		}
		String word = NumberToWord.numberInWords(fact);
		System.out.println(n + "! = " + fact + " (" + word + ")");
	}

}
