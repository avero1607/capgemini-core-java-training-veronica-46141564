package programs;

import java.util.Scanner;

public class ChangeCase {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Input:");
		String input = sc.nextLine();
		toUpperCase(input);
		toLowerCase(input);
		toCapitalize(input);
		toSentenceCase(input);
		toInvertCase(input);
	}

	private static void toInvertCase(String input) {
		StringBuffer output = new StringBuffer(input);
		for(int i=0; i<input.length(); i++) {
			if(Character.isUpperCase(input.charAt(i))) {
				output.setCharAt(i, Character.toLowerCase(input.charAt(i)));
			}else if(Character.isLowerCase(input.charAt(i))) {
				output.setCharAt(i, Character.toUpperCase(input.charAt(i)));
			}
		}
		System.out.println("\nInvert:\n" + " " + output);
	}

	private static void toSentenceCase(String input) {
		String[] sentences = input.split("\\.");
		String firstLetterCapitalizedWord = "";
		String sentenceCase = "";
		for(String sentence: sentences) {
	        String firstLetStr = sentence.trim().substring(0, 1).toUpperCase();
	        String remLetStr = sentence.trim().substring(1).toLowerCase();	 
	        firstLetterCapitalizedWord = firstLetStr + remLetStr;
			sentenceCase += firstLetterCapitalizedWord + ". ";
		}
		System.out.print("Sentence case:\n" + " " + sentenceCase.substring(0, sentenceCase.length()-2));
	}

	private static void toCapitalize(String input) {
		String[] words = input.split(" ");
		String capitalizedWord = "";
		for(String word: words) {
			String firstLetter = word.substring(0, 1);
			String remainingLetters = word.substring(1);
			capitalizedWord += firstLetter.toUpperCase() + remainingLetters + " ";
		}
		System.out.println("Capitalize:\n" + " " + capitalizedWord.trim());
	}

	private static void toLowerCase(String input) {
		System.out.println("Lower case:\n" + " " + input.toLowerCase());
	}

	private static void toUpperCase(String input) {
		System.out.println("Upper case:\n" + " " + input.toUpperCase());
	}

}
