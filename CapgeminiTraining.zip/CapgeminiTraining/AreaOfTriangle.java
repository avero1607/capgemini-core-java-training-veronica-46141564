package programs;

import java.util.Scanner;

public class AreaOfTriangle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Point A (x,y): ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		CoordinatesOfPoints A = new CoordinatesOfPoints(a,b);
		System.out.println("Point B (x,y): ");
		int c = sc.nextInt();
		int d = sc.nextInt();
		CoordinatesOfPoints B = new CoordinatesOfPoints(c,d);
		System.out.println("Point C (x,y): ");
		int e = sc.nextInt();
		int f = sc.nextInt();
		CoordinatesOfPoints C = new CoordinatesOfPoints(e,f);
		System.out.println("Area = "+ Triangle.area(A, B, C));
	}
}
	
	class CoordinatesOfPoints{
		int x;
		int y;
		public CoordinatesOfPoints(int x, int y) {
		    this.x = x;
		    this.y = y;
		  }
	}
	
	class Triangle {
		  public static float area(CoordinatesOfPoints A, CoordinatesOfPoints B, CoordinatesOfPoints C) {
		    int area = (A.x * (B.y - C.y) 
		                    + B.x * (C.y - A.y) + C.x * (A.y - B.y)) / 2;
		    return Math.abs(area);
		  }
	}

